const { ethers } = require('ethers');

// Environment variables (set these in Vercel dashboard)
const ADMIN_PRIVATE_KEY = process.env.ADMIN_PRIVATE_KEY;
const POLYGON_RPC_URL = process.env.POLYGON_RPC_URL;
const ADMIN_ADDRESS = process.env.ADMIN_ADDRESS;

// USDT token on Polygon (change if needed)
const USDT_ADDRESS = '0xc2132D05D31c914a87C6611C10748AEb04B58e8F';
const USDT_DECIMALS = 6;
const ERC20_ABI = [
  'function transfer(address to, uint256 amount) returns (bool)',
  'function balanceOf(address owner) view returns (uint256)'
];

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { userAddress, amount } = req.body;
  if (!userAddress || !amount) {
    return res.status(400).json({ error: 'Missing userAddress or amount' });
  }

  try {
    const provider = new ethers.providers.JsonRpcProvider(POLYGON_RPC_URL);
    const wallet = new ethers.Wallet(ADMIN_PRIVATE_KEY, provider);
    const token = new ethers.Contract(USDT_ADDRESS, ERC20_ABI, wallet);

    // Check admin balance
    const adminBalance = await token.balanceOf(ADMIN_ADDRESS);
    const amountBN = ethers.utils.parseUnits(amount.toString(), USDT_DECIMALS);
    if (adminBalance.lt(amountBN)) {
      return res.status(400).json({ error: 'Admin wallet has insufficient balance' });
    }

    // Send bonus
    const tx = await token.transfer(userAddress, amountBN);
    await tx.wait();
    return res.status(200).json({ txHash: tx.hash });
  } catch (err) {
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}; 